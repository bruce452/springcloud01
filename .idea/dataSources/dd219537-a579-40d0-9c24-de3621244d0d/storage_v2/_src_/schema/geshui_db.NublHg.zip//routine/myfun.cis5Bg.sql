create
  definer = root@localhost function myfun() returns int
BEGIN
	DECLARE res int DEFAULT 0;
	select count(1) into res
	from geshui_db.filestate_info;
	return res;
end;

